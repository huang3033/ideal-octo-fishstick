package com.fenglin.springboottest.common;

/**
 * 业务异常：由业务逻辑主动抛出，交给 {@link GlobalExceptionHandler} 统一转换
 * 成 {@link Result}，避免在 Controller 里写一堆 if-else 拼装返回值。
 */
public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /** 状态码，默认 400（参数/业务错误） */
    private final int code;

    public BusinessException(String message) {
        this(ResultCode.FAIL.getCode(), message);
    }

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public static BusinessException unauthorized(String message) {
        return new BusinessException(ResultCode.UNAUTHORIZED.getCode(), message);
    }

    public int getCode() {
        return code;
    }
}
