package com.fenglin.springboottest.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理：把各种异常统一转换成 {@link Result}，
 * 保证前端拿到的永远是同一套 JSON 结构，不用在页面里写一堆 try-catch 分支。
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** 业务异常：账号已存在、验证码错误、密码错误等 */
    @ExceptionHandler(BusinessException.class)
    public Result<Void> handleBusinessException(BusinessException e) {
        log.warn("业务异常：{}", e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    }

    /** @Valid 校验失败（@RequestBody 对象） */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValidException(MethodArgumentNotValidException e) {
        String message = firstErrorMessage(e.getBindingResult().getFieldErrors().isEmpty()
                ? null : e.getBindingResult().getFieldError());
        return Result.fail(message);
    }

    /** @Valid 校验失败（表单对象） */
    @ExceptionHandler(BindException.class)
    public Result<Void> handleBindException(BindException e) {
        String message = firstErrorMessage(e.getBindingResult().getFieldErrors().isEmpty()
                ? null : e.getBindingResult().getFieldError());
        return Result.fail(message);
    }

    /** 请求体不是合法 JSON */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Result<Void> handleNotReadable(HttpMessageNotReadableException e) {
        log.warn("请求体解析失败：{}", e.getMessage());
        return Result.fail("请求参数格式不正确");
    }

    /** 请求方法不支持，例如 GET 调了 POST 接口 */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Result<Void> handleMethodNotSupported(HttpRequestMethodNotSupportedException e) {
        return Result.fail("请求方式不支持，请使用 " + e.getSupportedHttpMethods());
    }

    /** 唯一索引冲突：并发注册同一个账号时兜底 */
    @ExceptionHandler(DuplicateKeyException.class)
    public Result<Void> handleDuplicateKey(DuplicateKeyException e) {
        log.warn("唯一索引冲突：{}", e.getMessage());
        return Result.fail("该账号已被注册，请直接登录或更换账号");
    }

    /** 兜底异常：打印完整堆栈，但不把内部细节暴露给前端 */
    @ExceptionHandler(Exception.class)
    public Result<Void> handleException(Exception e) {
        log.error("系统异常", e);
        return Result.fail(ResultCode.ERROR);
    }

    private String firstErrorMessage(FieldError fieldError) {
        if (fieldError == null) {
            return "请求参数校验失败";
        }
        String defaultMessage = fieldError.getDefaultMessage();
        return defaultMessage == null ? "参数 " + fieldError.getField() + " 校验失败" : defaultMessage;
    }
}
