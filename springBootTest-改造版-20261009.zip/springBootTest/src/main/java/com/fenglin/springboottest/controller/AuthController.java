package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.BusinessException;
import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.component.CaptchaStore;
import com.fenglin.springboottest.dto.CaptchaVO;
import com.fenglin.springboottest.dto.LoginRequest;
import com.fenglin.springboottest.dto.RegisterRequest;
import com.fenglin.springboottest.dto.UserVO;
import com.fenglin.springboottest.service.UserService;
import com.fenglin.springboottest.util.CaptchaUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 账号认证接口
 * <p>
 * 所有接口统一返回 {@link Result} JSON，前端只需要判断 code == 200。
 * <pre>
 * GET  /api/auth/captcha                    获取图形验证码（返回 base64 图片 + uuid）
 * GET  /api/auth/check-username?username=x  校验账号是否可注册
 * POST /api/auth/register                   注册
 * POST /api/auth/login                      登录
 * POST /api/auth/logout                     退出登录
 * GET  /api/auth/me                         获取当前登录用户
 * </pre>
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    /** session 中保存当前登录用户 id 的 key */
    public static final String SESSION_USER_ID = "ACCOUNT_CENTER_USER_ID";

    /** 验证码有效期（秒），与 CaptchaStore 内部保持一致 */
    private static final int CAPTCHA_EXPIRE_SECONDS = 120;

    private final UserService userService;
    private final CaptchaStore captchaStore;

    public AuthController(UserService userService, CaptchaStore captchaStore) {
        this.userService = userService;
        this.captchaStore = captchaStore;
    }

    /**
     * 获取图形验证码
     */
    @GetMapping("/captcha")
    public Result<CaptchaVO> captcha() {
        CaptchaStore.Captcha captcha = captchaStore.generate();
        CaptchaVO vo = new CaptchaVO(
                captcha.uuid(),
                CaptchaUtil.toBase64Png(captcha.code()),
                CAPTCHA_EXPIRE_SECONDS,
                CaptchaUtil.CODE_LENGTH);
        return Result.ok(vo);
    }

    /**
     * 校验账号是否可注册（注册页账号输入框失焦时调用，提前给出友好提示）
     */
    @GetMapping("/check-username")
    public Result<Map<String, Object>> checkUsername(@RequestParam("username") String username) {
        boolean available = userService.isUsernameAvailable(username);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", username);
        data.put("available", available);
        data.put("message", available ? "该账号可以使用" : "该账号已被注册");
        return Result.ok(data);
    }

    /**
     * 注册
     */
    @PostMapping("/register")
    public Result<UserVO> register(@Valid @RequestBody RegisterRequest request) {
        UserVO user = userService.register(request);
        return Result.ok("注册成功，请登录", user);
    }

    /**
     * 登录：登录成功后把用户 id 写入 session，后续 /me 与 /logout 依赖它
     */
    @PostMapping("/login")
    public Result<UserVO> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        String clientIp = resolveClientIp(httpRequest);
        UserVO user = userService.login(request, clientIp);

        HttpSession session = httpRequest.getSession(true);
        session.setAttribute(SESSION_USER_ID, user.getId());

        boolean rememberMe = Boolean.TRUE.equals(request.getRememberMe());
        // 勾选「记住我」则延长会话有效期（默认 30 分钟 -> 7 天）
        session.setMaxInactiveInterval(rememberMe ? 7 * 24 * 60 * 60 : 30 * 60);

        return Result.ok("登录成功", user);
    }

    /**
     * 退出登录：只清空本系统的登录标记，不销毁整个 session
     */
    @PostMapping("/logout")
    public Result<Void> logout(HttpServletRequest httpRequest) {
        HttpSession session = httpRequest.getSession(false);
        if (session != null) {
            session.removeAttribute(SESSION_USER_ID);
        }
        return Result.ok("已退出登录", null);
    }

    /**
     * 获取当前登录用户；未登录返回 401
     */
    @GetMapping("/me")
    public Result<UserVO> me(HttpServletRequest httpRequest) {
        HttpSession session = httpRequest.getSession(false);
        Object userId = session == null ? null : session.getAttribute(SESSION_USER_ID);
        if (userId == null) {
            throw BusinessException.unauthorized("尚未登录或登录已过期");
        }
        UserVO user = userService.getCurrentUser(Long.valueOf(userId.toString()));
        if (user == null) {
            throw BusinessException.unauthorized("账号不存在或已被删除");
        }
        return Result.ok(user);
    }

    /**
     * 获取客户端真实 IP：经过 Nginx 等反向代理时优先取 X-Forwarded-For
     */
    private String resolveClientIp(HttpServletRequest request) {
        String[] headers = {"X-Forwarded-For", "X-Real-IP", "Proxy-Client-IP", "WL-Proxy-Client-IP"};
        for (String header : headers) {
            String ip = request.getHeader(header);
            if (StringUtils.hasText(ip) && !"unknown".equalsIgnoreCase(ip)) {
                // X-Forwarded-For 可能是「客户端IP, 代理1, 代理2」，取第一个
                int comma = ip.indexOf(',');
                return comma > 0 ? ip.substring(0, comma).trim() : ip.trim();
            }
        }
        return request.getRemoteAddr();
    }
}
