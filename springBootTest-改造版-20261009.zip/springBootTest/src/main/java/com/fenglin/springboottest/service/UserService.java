package com.fenglin.springboottest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.fenglin.springboottest.dto.LoginRequest;
import com.fenglin.springboottest.dto.RegisterRequest;
import com.fenglin.springboottest.dto.UserVO;
import com.fenglin.springboottest.entity.User;

/**
 * 用户业务接口
 * <p>
 * 继承 IService 后自带 save / getById / list / page 等通用方法，
 * 这里只声明登录注册相关的业务能力。
 */
public interface UserService extends IService<User> {

    /**
     * 注册
     *
     * @param request 注册参数（含图形验证码）
     * @return 注册成功的用户信息（不含密码）
     */
    UserVO register(RegisterRequest request);

    /**
     * 登录
     *
     * @param request  登录参数
     * @param clientIp 客户端 IP，用于记录最后登录信息
     * @return 登录成功的用户信息（不含密码）
     */
    UserVO login(LoginRequest request, String clientIp);

    /**
     * 账号是否可注册（注册页失焦实时校验用）
     */
    boolean isUsernameAvailable(String username);

    /**
     * 按主键查询用户（脱敏）
     */
    UserVO getCurrentUser(Long userId);
}
