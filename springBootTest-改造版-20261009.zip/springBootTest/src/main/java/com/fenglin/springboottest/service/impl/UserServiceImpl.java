package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.common.BusinessException;
import com.fenglin.springboottest.component.CaptchaStore;
import com.fenglin.springboottest.dto.LoginRequest;
import com.fenglin.springboottest.dto.RegisterRequest;
import com.fenglin.springboottest.dto.UserVO;
import com.fenglin.springboottest.entity.User;
import com.fenglin.springboottest.mapper.UserMapper;
import com.fenglin.springboottest.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

/**
 * 用户业务实现
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    /** 账号状态：正常 */
    private static final int STATUS_NORMAL = 1;

    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    private final CaptchaStore captchaStore;

    /**
     * 构造器注入（比 @Autowired 字段注入更好：依赖不可变、便于单元测试）
     */
    public UserServiceImpl(UserMapper userMapper,
                           PasswordEncoder passwordEncoder,
                           CaptchaStore captchaStore) {
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
        this.captchaStore = captchaStore;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UserVO register(RegisterRequest request) {
        // 1. 校验图形验证码（一次性，校验后立刻失效）
        if (!captchaStore.verify(request.getCaptchaUuid(), request.getCode())) {
            throw new BusinessException("图片验证码不正确或已过期，请点击图片刷新后重试");
        }

        String username = request.getUsername().trim();

        // 2. 两次密码一致性（前端也校验了，后端再兜一次，防止绕过页面直接调接口）
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new BusinessException("两次输入的密码不一致");
        }

        // 3. 账号查重
        if (!isUsernameAvailable(username)) {
            throw new BusinessException("该账号已被注册，请直接登录或更换账号");
        }

        // 4. 组装实体，密码 BCrypt 加密后入库
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setNickname(StringUtils.hasText(request.getNickname())
                ? request.getNickname().trim()
                : defaultNickname(username));
        user.setStatus(STATUS_NORMAL);
        user.setDeleted(0);

        // 5. 保存（并发下若唯一索引冲突，会由 GlobalExceptionHandler 转成友好提示）
        save(user);
        log.info("新用户注册成功：id={}, username={}", user.getId(), user.getUsername());
        return UserVO.from(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UserVO login(LoginRequest request, String clientIp) {
        String username = request.getUsername().trim();

        // 1. 按账号查询（包含密码字段，仅此处使用）
        User user = userMapper.selectByUsername(username);

        // 2. 账号不存在 / 密码错误：统一提示，避免暴露账号是否存在的枚举风险
        if (user == null) {
            log.warn("登录失败：账号不存在，username={}", username);
            throw new BusinessException("账号或密码错误");
        }
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("登录失败：密码错误，username={}", username);
            throw new BusinessException("账号或密码错误");
        }

        // 3. 账号状态校验
        if (user.getStatus() == null || user.getStatus() != STATUS_NORMAL) {
            throw new BusinessException("该账号已被禁用，请联系管理员");
        }

        // 4. 记录最后登录信息
        LocalDateTime now = LocalDateTime.now();
        userMapper.updateLastLogin(user.getId(), now, clientIp);
        user.setLastLoginTime(now);
        log.info("登录成功：id={}, username={}, ip={}", user.getId(), user.getUsername(), clientIp);

        return UserVO.from(user);
    }

    @Override
    public boolean isUsernameAvailable(String username) {
        if (!StringUtils.hasText(username)) {
            return false;
        }
        return userMapper.countByUsername(username.trim()) == 0;
    }

    @Override
    public UserVO getCurrentUser(Long userId) {
        if (userId == null) {
            return null;
        }
        return UserVO.from(getById(userId));
    }

    /** 昵称默认取账号名（超长则截断到 16 位） */
    private String defaultNickname(String username) {
        return username.length() > 16 ? username.substring(0, 16) : username;
    }
}
