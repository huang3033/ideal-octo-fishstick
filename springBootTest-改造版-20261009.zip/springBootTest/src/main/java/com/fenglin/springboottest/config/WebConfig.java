package com.fenglin.springboottest.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web 相关配置：密码加密器 + 跨域放行
 * <p>
 * 注意：这里只引入了 spring-security-crypto 这一个 jar 做 BCrypt 加密，
 * 并没有引入完整的 spring-boot-starter-security，所以不会有默认登录页和拦截全部请求的问题。
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * 密码加密器：BCrypt 自带随机盐，同一个密码每次加密结果都不同，
     * 数据库里永远看不到明文密码。强度 10 是默认值，够用且性能均衡。
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * 跨域配置：
     * - 如果前端页面由本工程直接提供（http://localhost:8081/login.html），属于同源，本配置不生效也无所谓；
     * - 如果以后前端独立用 Vue 工程跑（vite 默认 5173 端口），靠这段配置放行；
     *   allowCredentials(true) 是为了让 session 能被跨域携带。
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
