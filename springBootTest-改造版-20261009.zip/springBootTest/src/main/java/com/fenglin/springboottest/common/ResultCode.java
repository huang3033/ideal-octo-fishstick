package com.fenglin.springboottest.common;

/**
 * 统一响应状态码
 */
public enum ResultCode {

    /** 成功 */
    SUCCESS(200, "操作成功"),
    /** 业务/参数异常（前端可直接把 message 弹出来） */
    FAIL(400, "操作失败"),
    /** 未登录或登录已过期 */
    UNAUTHORIZED(401, "登录已失效，请重新登录"),
    /** 服务端异常 */
    ERROR(500, "服务器开小差了，请稍后再试");

    private final int code;
    private final String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
