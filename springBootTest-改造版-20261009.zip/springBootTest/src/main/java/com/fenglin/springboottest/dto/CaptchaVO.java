package com.fenglin.springboottest.dto;

import java.io.Serializable;

/**
 * 图形验证码返回结果
 */
public class CaptchaVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 验证码唯一标识，登录/注册时需原样带回 */
    private String uuid;

    /** data:image/png;base64,... 形式，前端直接赋给 <img src> */
    private String image;

    /** 有效期（秒） */
    private int expireSeconds;

    /** 验证码位数，前端可用于限制输入框 maxlength */
    private int codeLength;

    public CaptchaVO() {
    }

    public CaptchaVO(String uuid, String image, int expireSeconds, int codeLength) {
        this.uuid = uuid;
        this.image = image;
        this.expireSeconds = expireSeconds;
        this.codeLength = codeLength;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getExpireSeconds() {
        return expireSeconds;
    }

    public void setExpireSeconds(int expireSeconds) {
        this.expireSeconds = expireSeconds;
    }

    public int getCodeLength() {
        return codeLength;
    }

    public void setCodeLength(int codeLength) {
        this.codeLength = codeLength;
    }
}
