package com.fenglin.springboottest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * 注册请求参数（对应 register.html 表单）
 */
public class RegisterRequest {

    /** 登录账号 */
    @NotBlank(message = "请输入账号")
    @Size(min = 4, max = 64, message = "账号长度需在 4-64 位之间")
    @Pattern(regexp = "^[A-Za-z0-9_-]+$", message = "账号只能包含字母、数字和下划线")
    private String username;

    /** 密码：至少 8 位且同时包含字母与数字 */
    @NotBlank(message = "请输入密码")
    @Size(min = 8, max = 32, message = "密码长度需在 8-32 位之间")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "密码需同时包含字母和数字")
    private String password;

    /** 确认密码：前端已校验一次，后端再兜一次底 */
    @NotBlank(message = "请再次输入密码")
    private String confirmPassword;

    /** 图形验证码（不区分大小写） */
    @NotBlank(message = "请输入图片验证码")
    private String code;

    /** 图形验证码对应的唯一标识，由 /api/auth/captcha 返回 */
    @NotBlank(message = "验证码已失效，请点击图片刷新后重试")
    private String captchaUuid;

    /** 昵称，可空；为空时后端自动用账号名生成 */
    private String nickname;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCaptchaUuid() {
        return captchaUuid;
    }

    public void setCaptchaUuid(String captchaUuid) {
        this.captchaUuid = captchaUuid;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}
