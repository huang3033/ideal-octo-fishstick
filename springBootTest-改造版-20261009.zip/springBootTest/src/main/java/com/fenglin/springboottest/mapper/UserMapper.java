package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;

/**
 * 用户 Mapper
 * <p>
 * 继承 BaseMapper 后，单表增删改查（insert / selectById / selectOne / updateById ...）全部自带，
 * 复杂 SQL 可以像下面这样用注解写，也可以放到 resources/mapper/UserMapper.xml 里。
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /**
     * 按账号查询用户（包含密码字段，仅用于登录校验）
     */
    @Select("SELECT id, username, password, nickname, status, last_login_time, last_login_ip, create_time, update_time "
            + "FROM sys_user WHERE username = #{username} AND deleted = 0 LIMIT 1")
    User selectByUsername(@Param("username") String username);

    /**
     * 统计账号是否存在（注册前查重，比查整行更轻）
     */
    @Select("SELECT COUNT(1) FROM sys_user WHERE username = #{username} AND deleted = 0")
    int countByUsername(@Param("username") String username);

    /**
     * 更新最后登录信息
     */
    @Update("UPDATE sys_user SET last_login_time = #{loginTime}, last_login_ip = #{loginIp}, update_time = #{loginTime} "
            + "WHERE id = #{id}")
    int updateLastLogin(@Param("id") Long id,
                        @Param("loginTime") LocalDateTime loginTime,
                        @Param("loginIp") String loginIp);
}
