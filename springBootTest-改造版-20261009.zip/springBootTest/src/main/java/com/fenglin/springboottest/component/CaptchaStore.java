package com.fenglin.springboottest.component;

import com.fenglin.springboottest.util.CaptchaUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 图形验证码存储器
 * <p>
 * 为什么不用 HttpSession 存？
 * 因为前端以后可能独立成 Vue 工程（不同端口甚至不同域名），session 容易受 Cookie / 跨域限制；
 * 用「uuid + 内存 Map」的方式对前后端分离更友好，前端只要把 uuid 一起提交回来即可。
 * <p>
 * 特性：
 * 1. 有效期 2 分钟，过期自动失效；
 * 2. 一次一用（校验后立即删除），防止同一张验证码被反复提交；
 * 3. 校验不区分大小写。
 * <p>
 * 生产环境多实例部署时，把这里换成 Redis 实现即可（对外方法签名保持不变，调用方无需改动）。
 */
@Component
public class CaptchaStore {

    private static final Logger log = LoggerFactory.getLogger(CaptchaStore.class);

    /** 有效期：2 分钟 */
    private static final long EXPIRE_MILLIS = 2 * 60 * 1000L;

    /** 最多允许同时存在的验证码数量，防止被恶意刷爆内存 */
    private static final int MAX_SIZE = 10_000;

    private final Map<String, CaptchaItem> store = new ConcurrentHashMap<>();

    /**
     * 生成一个新的验证码，返回「标识 + 文本」。
     * 调用方用 code 渲染图片，把 uuid 一起返回给前端。
     */
    public Captcha generate() {
        evictExpired();
        if (store.size() >= MAX_SIZE) {
            store.clear();
        }
        String code = CaptchaUtil.randomCode();
        String uuid = UUID.randomUUID().toString().replace("-", "");
        store.put(uuid, new CaptchaItem(code, System.currentTimeMillis() + EXPIRE_MILLIS));
        // 仅 DEBUG 级别输出，方便本地联调（dev 环境开启了 debug，生产环境是 info 不会打印）
        log.debug("生成图形验证码：uuid={}, code={}", uuid, code);
        return new Captcha(uuid, code);
    }

    /**
     * 校验验证码；无论成功失败都会把该 uuid 移除（保证一次一用）
     *
     * @return true 表示校验通过
     */
    public boolean verify(String uuid, String inputCode) {
        if (uuid == null || inputCode == null) {
            return false;
        }
        CaptchaItem item = store.remove(uuid);
        if (item == null || item.expireAt() < System.currentTimeMillis()) {
            return false;
        }
        return item.code().equalsIgnoreCase(inputCode.trim());
    }

    /** 清理过期项，避免内存里堆积无用数据 */
    private void evictExpired() {
        long now = System.currentTimeMillis();
        store.entrySet().removeIf(entry -> entry.getValue().expireAt() < now);
    }

    /** 当前有效验证码数量（调试观测用） */
    public int size() {
        return store.size();
    }

    /**
     * 一条验证码记录
     *
     * @param code     验证码文本
     * @param expireAt 过期时间戳（毫秒）
     */
    private record CaptchaItem(String code, long expireAt) {
    }

    /**
     * 生成结果：uuid 给前端保存，code 用于绘制图片
     */
    public record Captcha(String uuid, String code) {
    }
}
