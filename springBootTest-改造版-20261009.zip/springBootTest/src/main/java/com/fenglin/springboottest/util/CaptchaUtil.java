package com.fenglin.springboottest.util;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * 图形验证码工具
 * <p>
 * 纯 JDK 实现（BufferedImage + ImageIO），不引入额外依赖。
 * 配色刻意贴合前端「墨色鎏金」的深色卡片：深底 + 金色字符。
 * <p>
 * 注意：只负责生成图片，验证码的保存与校验由 {@code CaptchaStore} 负责。
 */
public final class CaptchaUtil {

    /** 去掉了容易混淆的 0 O 1 I L */
    private static final char[] CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();

    private static final SecureRandom RANDOM = new SecureRandom();

    /** 与前端 canvas 保持一致的尺寸（正好填满 116x46 的验证码框） */
    private static final int WIDTH = 116;
    private static final int HEIGHT = 46;

    /** 验证码字符个数 */
    public static final int CODE_LENGTH = 4;

    private CaptchaUtil() {
    }

    /**
     * 生成随机验证码（纯字母数字，便于用户辨认）
     */
    public static String randomCode() {
        StringBuilder sb = new StringBuilder(CODE_LENGTH);
        for (int i = 0; i < CODE_LENGTH; i++) {
            sb.append(CHARS[RANDOM.nextInt(CHARS.length)]);
        }
        return sb.toString();
    }

    /**
     * 把验证码绘制成 PNG，并返回 data:image/png;base64,... 形式，
     * 前端拿到后直接 <img src="..."> 即可显示，无需额外的图片接口。
     */
    public static String toBase64Png(String code) {
        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            // 背景：与登录卡片的深色玻璃底一致
            g.setColor(new Color(0x16, 0x1B, 0x22));
            g.fillRect(0, 0, WIDTH, HEIGHT);

            // 干扰线
            g.setStroke(new BasicStroke(1f));
            for (int i = 0; i < 4; i++) {
                g.setColor(new Color(201, 169, 106, 30 + RANDOM.nextInt(40)));
                g.drawLine(RANDOM.nextInt(WIDTH), RANDOM.nextInt(HEIGHT),
                        RANDOM.nextInt(WIDTH), RANDOM.nextInt(HEIGHT));
            }

            // 干扰点
            for (int i = 0; i < 26; i++) {
                g.setColor(new Color(255, 255, 255, 20 + RANDOM.nextInt(30)));
                int x = RANDOM.nextInt(WIDTH);
                int y = RANDOM.nextInt(HEIGHT);
                g.fillOval(x, y, 2, 2);
            }

            // 字符：依次绘制，带少量旋转与位移
            Color[] shades = {new Color(0xE3, 0xC8, 0x94), new Color(0xC9, 0xA9, 0x6A),
                    new Color(0xD8, 0xBD, 0x86), new Color(0xBF, 0xA0, 0x67)};
            int step = WIDTH / (CODE_LENGTH + 1);
            for (int i = 0; i < code.length(); i++) {
                int fontSize = 20 + RANDOM.nextInt(6);
                g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, fontSize));
                g.setColor(shades[RANDOM.nextInt(shades.length)]);
                double angle = (RANDOM.nextDouble() - 0.5) * 0.5;
                int x = step * (i + 1);
                int y = HEIGHT / 2 + (RANDOM.nextInt(7) - 3);
                g.rotate(angle, x, y);
                g.drawString(String.valueOf(code.charAt(i)), x - fontSize / 3, y + fontSize / 3);
                g.rotate(-angle, x, y);
            }
        } finally {
            g.dispose();
        }

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ImageIO.write(image, "png", out);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(out.toByteArray());
        } catch (IOException e) {
            // 绘制内存图片几乎不会失败，真失败说明环境异常，交给全局异常处理
            throw new IllegalStateException("验证码图片生成失败", e);
        }
    }
}
