# AI_CONTEXT.md —— 给「我自己（WorkBuddy）」的下次启动速记

> 用途：这台电脑每次开机都会重置（node_modules / target 会被删，源码保留）。
> 下次被叫来处理本项目时，**先读这个文件**，避免把下面这些已经踩过的坑再踩一遍。
> 本文件跟随源码走，重置后仍在。配套脚本：项目根目录 `start.bat` / `stop.bat`。

---

## 0. 一句话结论
这是一个 Spring Boot 3 登录/注册后端，已和前端 HTML 接通、邮箱功能已下线。
**重置后唯一要做的**：双击 `start.bat`（自动起 MySQL→建库→Maven 打包→起服务）。

## 1. 项目身份
- 工作目录（改造版，唯一真相源）：`C:\Users\Administrator\WorkBuddy\<日期>\springBootTest\`
- 原始空壳：`D:\workSpace\springBootTest`（**未改造**，别把它当工作副本）
- 技术栈：Spring Boot 3.4.5 + MyBatis-Plus 3.5.9 + MySQL 8.0.39 + BCrypt（只引 `spring-security-crypto`）
- 启动端口：**8081**（必须显式 `--server.port=8081`，原因见坑①）
- 包名：com.fenglin.springboottest；jar：`target/springBootTest-0.0.1-SNAPSHOT.jar`

## 2. 已经做完的事（别重做）
- 接口：`GET /api/auth/captcha`、`GET /api/auth/check-username`、`POST /api/auth/register`、
  `POST /api/auth/login`、`POST /api/auth/logout`、`GET /api/auth/me`
- 统一返回 `{code,message,data}`：200 成功 / 400 业务错 / 401 未登录
- 数据库 `account_center.sys_user`（账号唯一索引、逻辑删除、时间戳由 DB 维护）
- 体验账号 **admin / Admin@123456**；SQL 在 `sql/schema.sql`（已幂等，可重复跑）
- 前端 `login.html` / `register.html` 已用 fetch 接真实接口；验证码改后端生成
- 邮箱功能全栈下线（页面文案、DTO/Entity/VO/Mapper/Service/建表脚本/库表列都清理了）
- 两个前端 HTML 各有一份：`Desktop\222\22.huang\` 与 `src\main\resources\static\`，需保持同步

## 3. 必看的坑（重置后最费时间的地方）
1. **`SERVER__PORT` 环境变量会抢端口**：本机有个 env var 把 server.port 指向已占用端口，
   不显式传 `--server.port=8081` 就会启动失败。脚本已内置，自己跑命令也要带上。
2. **Git Bash 跑不了 `./mvnw`**（MSYS 路径转换破坏 wrapper）。在 Git Bash 里用
   `sh scripts/mvn-run.sh clean package`（scripts/ 里已放好 classworlds 直拉脚本）；
   在用户机器上直接双击 `start.bat`（cmd 下 `mvnw.cmd` 正常）。
3. **MyBatis-Plus 3.5.9 必须额外加 `mybatis-plus-jsqlparser`**，否则分页拦截器编译报
   “找不到符号 PaginationInnerInterceptor”。已在 pom.xml。
4. **只引 `spring-security-crypto`，别引整包 spring-security**；否则默认拦截所有请求。
5. **重置后 .m2 仓库可能也被清**：首次 `mvnw` 会联网下载 Maven 发行包+依赖，较慢，属正常。
6. **MySQL 服务重置后可能没起**：`start.bat` 已 `net start MySQL80`；Navicat 连不上先查服务。
7. **前端 HTML 双份**：改一处要同步另一处，用 `diff` 校验。

## 4. 我（AI）在本环境怎么跑
- 构建（Git Bash）：`sh scripts/mvn-run.sh -B -DskipTests clean package`
- 运行：`java -jar target/springBootTest-0.0.1-SNAPSHOT.jar --server.port=8081`
- 接口冒烟：`sh scripts/api-test.sh`（自动从 `log/xx.log` 读验证码明文，13 项）
- 健康检查：`curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8081/api/auth/captcha`
- 停服务：`stop.bat`，或 `taskkill /PID <pid> /F`

## 5. 还缺什么（用户可能接下来要的）
- 「忘记密码」后端缺失：登录页有链接，但无 `/api/auth/reset-password` 之类接口
- 不是真 Vue 工程（原生 HTML + fetch）；迁 Vue 只需把 API_BASE 改成后端地址、改 axios
- 生产化未做：登录失败次数限制、验证码换 Redis、登录态换 JWT（现用内存 session）
- 没把改造版同步回 `D:\workSpace\springBootTest`（用户要时再做，先备份原文件）
- 无 JUnit 单测（只有 api-test.sh 冒烟）

## 6. 文件地图（常用）
- 入口/接口：`src/main/java/com/fenglin/springboottest/controller/AuthController.java`
- 业务：`service/impl/UserServiceImpl.java`；实体：`entity/User.java`；DTO：`dto/`
- 配置：`src/main/resources/application*.properties`、`config/`
- 前端：`src/main/resources/static/{login,register,index}.html`
- SQL：`sql/schema.sql`（幂等）；备份：`sql/backup/sys_user_before_drop_email.sql`
- 脚本：`start.bat`、`stop.bat`、`scripts/{mvn-run,run,api-test}.sh`

## 7. 数据库凭据
- host=127.0.0.1 user=root pass=123456 db=account_center
- 客户端：`C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe`
