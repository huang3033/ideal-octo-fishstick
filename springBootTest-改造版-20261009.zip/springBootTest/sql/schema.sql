-- =============================================================
--  账号中心 · 登录/注册模块 数据库初始化脚本（幂等版）
--  数据库：MySQL 8.0
--  字符集：utf8mb4 / utf8mb4_general_ci
--  说明：本脚本可重复执行。电脑重置 / 重新部署时直接跑即可，
--        不会删已有数据，也不会因“表已存在”报错。
--        执行方式（任选其一）：
--          mysql -uroot -p123456 < schema.sql
--          或双击项目根目录 start.bat（会自动调用本文件）
-- =============================================================

-- 1. 建库（不存在才创建，绝不删已有库）
CREATE DATABASE IF NOT EXISTS `account_center`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_general_ci;

USE `account_center`;

-- 2. 用户表（不存在才创建，保留已有数据）
--    登录账号统一存 username 字段（不支持邮箱登录）；
--    密码只存 BCrypt 密文，永不存明文。
CREATE TABLE IF NOT EXISTS `sys_user`
(
    `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `username`        VARCHAR(64)     NOT NULL COMMENT '登录账号',
    `password`        VARCHAR(100)    NOT NULL COMMENT '密码（BCrypt 加密密文，60 位左右）',
    `nickname`        VARCHAR(64)              DEFAULT NULL COMMENT '昵称',
    `status`          TINYINT         NOT NULL DEFAULT 1 COMMENT '账号状态：1-正常，0-禁用',
    `last_login_time` DATETIME                 DEFAULT NULL COMMENT '最后登录时间',
    `last_login_ip`   VARCHAR(64)              DEFAULT NULL COMMENT '最后登录IP',
    `create_time`     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `deleted`         TINYINT         NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`) COMMENT '账号唯一索引，防止重复注册'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE = utf8mb4_general_ci COMMENT ='用户表';

-- 3. 初始化体验账号（已存在则跳过，不会重复插入）
--    账号 admin / 密码 Admin@123456（下方为 BCrypt 密文）
INSERT IGNORE INTO `sys_user` (`username`, `password`, `nickname`, `status`)
VALUES ('admin',
        '$2a$10$3p2m33t6WtG3vR4s.qIK5OqE4VWud/CP53buxSaeTeEKbJhLx1X4e',
        '管理员',
        1);

-- 4. 常用排查语句
-- 查看所有用户：        SELECT id, username, nickname, status, create_time FROM sys_user;
-- 查看是否重复注册：    SELECT COUNT(1) FROM sys_user WHERE username = 'xxx';
-- 清空测试数据（慎用）：TRUNCATE TABLE sys_user;
