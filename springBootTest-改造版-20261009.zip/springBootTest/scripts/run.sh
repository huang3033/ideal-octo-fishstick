#!/bin/sh
# ============================================================
#  run.sh —— 启动本服务
#
#  为什么必须显式写 --server.port：
#    本机环境存在 SERVER__PORT 环境变量，Spring Boot 的宽松绑定会把
#    它当成 server.port，优先级高于 application-dev.properties，
#    结果绑到一个已被占用的端口并启动失败。
#    命令行参数优先级最高，显式传入即可覆盖。
#
#  用法：
#    sh scripts/run.sh            # 默认 8081
#    sh scripts/run.sh 9090       # 指定端口
#
#  IDEA 中运行：Run Configuration -> 程序参数填 --server.port=8081
# ============================================================
set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
cd "$PROJECT_DIR"

PORT=${1:-8081}
JAR=$(ls target/springBootTest-*.jar 2>/dev/null | grep -v original | head -1 || true)

if [ -z "$JAR" ]; then
    echo "[run] 未找到可执行 jar，正在打包 …"
    sh "$SCRIPT_DIR/mvn-run.sh" -B -DskipTests package
    JAR=$(ls target/springBootTest-*.jar | grep -v original | head -1)
fi

echo "[run] 启动 $JAR  端口=$PORT"
echo "[run] 登录页   http://127.0.0.1:$PORT/login.html"
echo "[run] 注册页   http://127.0.0.1:$PORT/register.html"
echo "[run] 首页     http://127.0.0.1:$PORT/index.html"

exec java -jar "$JAR" --server.port="$PORT"
