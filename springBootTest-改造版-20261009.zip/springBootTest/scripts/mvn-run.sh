#!/bin/sh
# ============================================================
#  mvn-run.sh —— 在 Windows + Git Bash(Git for Windows 自带 MSYS) 中运行 Maven
#
#  为什么需要它：
#    官方 mvn / mvnw 是 Unix shell 脚本，会把 "/c/Users/..." 这类路径直接传给
#    Windows 的 java.exe，于是报错：
#        找不到或无法加载主类 org.codehaus.plexus.classworlds.launcher.Launcher
#    本脚本改为用 Windows 风格路径（cygpath -m）直接拉起 classworlds 启动器，
#    绕开该问题，且无需 cmd.exe。
#
#  用法（在项目根目录或任意位置均可）：
#    sh scripts/mvn-run.sh -v
#    sh scripts/mvn-run.sh clean package -DskipTests
#    MAVEN_HOME=D:/apache-maven-3.9.9 sh scripts/mvn-run.sh compile
# ============================================================
set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
cd "$PROJECT_DIR"

# 1. 定位 Maven 发行包：优先用 MAVEN_HOME，其次用 wrapper 已下载的版本
MVN_HOME_UNIX=""
if [ -n "$MAVEN_HOME" ] && [ -d "$MAVEN_HOME/boot" ]; then
    MVN_HOME_UNIX="$MAVEN_HOME"
else
    MVN_HOME_UNIX=$(ls -d "$HOME"/.m2/wrapper/dists/apache-maven-*/[0-9a-z]*/apache-maven-* 2>/dev/null | head -1 || true)
fi

if [ -z "$MVN_HOME_UNIX" ] || [ ! -d "$MVN_HOME_UNIX/boot" ]; then
    echo "[mvn-run] 未找到可用的 Maven 发行包。" >&2
    echo "[mvn-run] 解决办法：先执行一次 ./mvnw -v 让 wrapper 自动下载，或显式设置 MAVEN_HOME。" >&2
    exit 1
fi

# 2. 转成 Windows 风格路径（java.exe 只认这种）
MVN_HOME_WIN=$(cygpath -m "$MVN_HOME_UNIX" 2>/dev/null || echo "$MVN_HOME_UNIX")
CLASSWORLDS_UNIX=$(ls "$MVN_HOME_UNIX"/boot/plexus-classworlds-*.jar | head -1)
CLASSWORLDS_WIN=$(cygpath -m "$CLASSWORLDS_UNIX" 2>/dev/null || echo "$CLASSWORLDS_UNIX")
PROJECT_DIR_WIN=$(cygpath -m "$PROJECT_DIR" 2>/dev/null || echo "$PROJECT_DIR")

echo "[mvn-run] maven home : $MVN_HOME_WIN"
echo "[mvn-run] project    : $PROJECT_DIR_WIN"
echo "[mvn-run] goals      : $*"

exec java \
    -classpath "$CLASSWORLDS_WIN" \
    "-Dclassworlds.conf=$MVN_HOME_WIN/bin/m2.conf" \
    "-Dmaven.home=$MVN_HOME_WIN" \
    "-Dmaven.multiModuleProjectDirectory=$PROJECT_DIR_WIN" \
    -Dfile.encoding=UTF-8 \
    org.codehaus.plexus.classworlds.launcher.Launcher "$@"
