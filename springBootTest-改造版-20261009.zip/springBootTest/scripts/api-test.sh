#!/bin/sh
# ============================================================
#  api-test.sh —— 登录/注册接口冒烟测试
#
#  前置：
#    1. 服务已启动（sh scripts/run.sh）
#    2. dev 环境已开启 debug 日志（application-dev.properties），
#       验证码明文会打印到 log/xx.log，本脚本从中读取，
#       从而可以全自动跑完带验证码的注册流程。
#
#  用法：
#    sh scripts/api-test.sh                       # 默认 http://127.0.0.1:8081
#    sh scripts/api-test.sh http://127.0.0.1:9090
# ============================================================
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_DIR=$(cd "$SCRIPT_DIR/.." && pwd)
cd "$PROJECT_DIR"

API=${1:-http://127.0.0.1:8081}
LOG=log/xx.log
COOKIE=target/api-test-cookie.txt
TEST_USER="testuser$(date +%H%M%S)"
TEST_PWD="Test123456"

UUID=""
CODE=""

new_captcha() {
    UUID=$(curl -s "$API/api/auth/captcha" | sed -E 's/.*"uuid":"([^"]+)".*/\1/')
    sleep 1
    CODE=$(grep -a "生成图形验证码" "$LOG" | tail -1 | sed -E 's/.*code=([A-Z0-9]+).*/\1/')
}

post() {
    curl -s -X POST "$API$1" -H "Content-Type: application/json" -d "$2" -b "$COOKIE" -c "$COOKIE"
}

echo "测试目标：$API    测试账号：$TEST_USER"
echo "============================================================"
echo "用例1  完整注册"
new_captcha
post /api/auth/register "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PWD\",\"confirmPassword\":\"$TEST_PWD\",\"nickname\":\"测试用户\",\"code\":\"$CODE\",\"captchaUuid\":\"$UUID\"}"
echo

echo "============================================================"
echo "用例2  重复注册（预期：该账号已被注册）"
new_captcha
post /api/auth/register "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PWD\",\"confirmPassword\":\"$TEST_PWD\",\"code\":\"$CODE\",\"captchaUuid\":\"$UUID\"}"
echo

echo "============================================================"
echo "用例3  验证码错误（预期：验证码不正确或已过期）"
new_captcha
post /api/auth/register "{\"username\":\"${TEST_USER}b\",\"password\":\"$TEST_PWD\",\"confirmPassword\":\"$TEST_PWD\",\"code\":\"XXXX\",\"captchaUuid\":\"$UUID\"}"
echo

echo "============================================================"
echo "用例4  密码不合规（预期：密码需同时包含字母和数字）"
new_captcha
post /api/auth/register "{\"username\":\"${TEST_USER}c\",\"password\":\"abcdef\",\"confirmPassword\":\"abcdef\",\"code\":\"$CODE\",\"captchaUuid\":\"$UUID\"}"
echo

echo "============================================================"
echo "用例5  账号查重（预期 available=false）"
curl -s "$API/api/auth/check-username?username=$TEST_USER"; echo

echo "============================================================"
echo "用例6  登录成功（新注册账号）"
post /api/auth/login "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PWD\",\"rememberMe\":true}"
echo

echo "============================================================"
echo "用例7  密码错误（预期：账号或密码错误）"
post /api/auth/login "{\"username\":\"$TEST_USER\",\"password\":\"WrongPass123\"}"
echo

echo "============================================================"
echo "用例8  账号不存在（预期同样提示账号或密码错误，避免账号枚举）"
post /api/auth/login '{"username":"not-exist-user","password":"Whatever123"}'
echo

echo "============================================================"
echo "用例9  登录后获取当前用户（预期 200）"
curl -s "$API/api/auth/me" -b "$COOKIE"; echo

echo "============================================================"
echo "用例10 退出登录"
post /api/auth/logout ''
echo

echo "============================================================"
echo "用例11 退出后再取当前用户（预期 401）"
curl -s "$API/api/auth/me" -b "$COOKIE"; echo

echo "============================================================"
echo "用例12 不带 Cookie 访问 /me（预期 401）"
curl -s "$API/api/auth/me"; echo

echo "============================================================"
echo "用例13 静态页面（预期均为 200）"
for page in login.html register.html index.html; do
    printf "  /%-14s -> %s\n" "$page" "$(curl -s -o /dev/null -w '%{http_code}' "$API/$page")"
done

rm -f "$COOKIE"
echo "============================================================"
echo "完成。若某条用例结果与预期不符，请看控制台 SQL 日志与 log/xx.log 定位。"
